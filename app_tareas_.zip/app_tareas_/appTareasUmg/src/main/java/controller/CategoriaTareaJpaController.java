
package controller;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.CategoriaTarea;


public class CategoriaTareaJpaController implements Serializable {
    
     private EntityManagerFactory emf = null;

    // Constructor que recibe la fábrica de EntityManager
    public CategoriaTareaJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    // Método para obtener un EntityManager que permite interactuar con la base de datos
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // Método para crear (insertar) una nueva categoría de tarea
    public void create(CategoriaTarea categoriaTarea) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin(); // Inicia la transacción
            em.persist(categoriaTarea); // Guarda la categoría en la base de datos
            em.getTransaction().commit(); // Finaliza la transacción
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para editar (actualizar) una categoría existente
    public void edit(CategoriaTarea categoriaTarea) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin(); // Inicia la transacción
            categoriaTarea = em.merge(categoriaTarea); // Actualiza los datos de la categoría
            em.getTransaction().commit(); // Finaliza la transacción
        } catch (Exception ex) {
            throw new Exception("Error al editar la categoría: " + ex.getMessage());
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para eliminar una categoría por su ID
    public void destroy(Integer id) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin(); // Inicia la transacción

            CategoriaTarea categoriaTarea;
            try {
                categoriaTarea = em.getReference(CategoriaTarea.class, id); // Obtiene referencia a la categoría
                categoriaTarea.getIdCategoria(); // Fuerza la carga (acceso a campo para validar existencia)
            } catch (EntityNotFoundException enfe) {
                throw new Exception("La categoría con id " + id + " no existe.");
            }

            em.remove(categoriaTarea); // Elimina la categoría
            em.getTransaction().commit(); // Finaliza la transacción
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para obtener todas las categorías
    public List<CategoriaTarea> findCategoriaTareaEntities() {
        return findCategoriaTareaEntities(true, -1, -1);
    }

    // Método para obtener categorías con paginación
    public List<CategoriaTarea> findCategoriaTareaEntities(int maxResults, int firstResult) {
        return findCategoriaTareaEntities(false, maxResults, firstResult);
    }

    // Método interno que realiza la consulta de todas o algunas categorías
    private List<CategoriaTarea> findCategoriaTareaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            // Construye consulta de criterios para seleccionar categorías
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(CategoriaTarea.class));
            Query q = em.createQuery(cq);

            // Si no se desea todas, aplica los límites
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }

            return q.getResultList(); // Devuelve la lista de categorías
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para buscar una categoría por su ID
    public CategoriaTarea findCategoriaTarea(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(CategoriaTarea.class, id); // Devuelve la categoría encontrada
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para contar cuántas categorías existen en total
    public int getCategoriaTareaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<CategoriaTarea> rt = cq.from(CategoriaTarea.class);
            cq.select(em.getCriteriaBuilder().count(rt)); // Conteo total
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue(); // Devuelve como entero
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    
    
    
}
