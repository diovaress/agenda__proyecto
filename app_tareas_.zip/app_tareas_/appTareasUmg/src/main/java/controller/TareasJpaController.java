
package controller;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.Tareas;


public class TareasJpaController {
    
    private EntityManagerFactory emf = null;

    // Constructor que recibe la fábrica de EntityManager
    public TareasJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    // Método que devuelve un EntityManager para interactuar con la base de datos
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // Método para crear (insertar) una nueva tarea en la base de datos
    public void create(Tareas tareas) {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin(); // Inicia la transacción

            // Asigna las fechas de creación y actualización
            tareas.setCreatedAt(new java.util.Date());
            tareas.setUpdatedAt(new java.util.Date());

            // Asocia correctamente la relación con Usuarios
            if (tareas.getUsuariosIdusuarios() != null) {
                tareas.setUsuariosIdusuarios(
                    em.getReference(
                        tareas.getUsuariosIdusuarios().getClass(),
                        tareas.getUsuariosIdusuarios().getIdusuarios()
                    )
                );
            }

            // Asocia correctamente la relación con CategoriaTarea
            if (tareas.getCategoriaTareaIdCategoria() != null) {
                tareas.setCategoriaTareaIdCategoria(
                    em.getReference(
                        tareas.getCategoriaTareaIdCategoria().getClass(),
                        tareas.getCategoriaTareaIdCategoria().getIdCategoria()
                    )
                );
            }

            em.persist(tareas); // Guarda la tarea en la base de datos
            em.getTransaction().commit(); // Finaliza la transacción
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para editar (actualizar) una tarea existente
    public void edit(Tareas tareas) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin(); // Inicia la transacción

            // Actualiza la fecha de modificación
            tareas.setUpdatedAt(new java.util.Date());

            tareas = em.merge(tareas); // Fusiona la tarea con los datos nuevos
            em.getTransaction().commit(); // Finaliza la transacción
        } catch (Exception ex) {
            throw new Exception("Error al editar tarea: " + ex.getMessage());
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para eliminar una tarea por su ID
    public void destroy(Long id) throws Exception {
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin(); // Inicia la transacción

            Tareas tareas;
            try {
                tareas = em.getReference(Tareas.class, id); // Obtiene referencia a la tarea
                tareas.getIdTarea(); // Fuerza la carga (acceso)
            } catch (EntityNotFoundException enfe) {
                throw new Exception("La tarea con id " + id + " no existe.");
            }

            em.remove(tareas); // Elimina la tarea
            em.getTransaction().commit(); // Finaliza la transacción
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para obtener todas las tareas
    public List<Tareas> findTareasEntities() {
        return findTareasEntities(true, -1, -1);
    }

    // Método para obtener una lista de tareas con paginación
    public List<Tareas> findTareasEntities(int maxResults, int firstResult) {
        return findTareasEntities(false, maxResults, firstResult);
    }

    // Método privado que puede devolver todas o algunas tareas, según parámetros
    private List<Tareas> findTareasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            // Se construye una consulta de criterios (tipo-safe)
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Tareas.class));
            Query q = em.createQuery(cq);

            // Aplica límites si no se quiere traer todas
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }

            return q.getResultList(); // Devuelve la lista de tareas
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para buscar una tarea específica por su ID
    public Tareas findTareas(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Tareas.class, id); // Busca y devuelve la tarea
        } finally {
            em.close(); // Cierra el EntityManager
        }
    }

    // Método para contar cuántas tareas existen en total
    public int getTareasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Tareas> rt = cq.from(Tareas.class);
            cq.select(em.getCriteriaBuilder().count(rt)); // Conteo total
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue(); // Devuelve como int
        } finally {
            em.close(); // Cierra el EntityManager
        }
    
    
    }
    
   
}
