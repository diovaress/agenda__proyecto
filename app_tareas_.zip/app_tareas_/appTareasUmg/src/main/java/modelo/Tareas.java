/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author selvi
 */
@Entity
@Table(name = "tareas")
@NamedQueries({
    @NamedQuery(name = "Tareas.findAll", query = "SELECT t FROM Tareas t"),
    @NamedQuery(name = "Tareas.findByIdTarea", query = "SELECT t FROM Tareas t WHERE t.idTarea = :idTarea"),
    @NamedQuery(name = "Tareas.findByFecha", query = "SELECT t FROM Tareas t WHERE t.fecha = :fecha"),
    @NamedQuery(name = "Tareas.findByPrioridad", query = "SELECT t FROM Tareas t WHERE t.prioridad = :prioridad"),
    @NamedQuery(name = "Tareas.findByTitulo", query = "SELECT t FROM Tareas t WHERE t.titulo = :titulo"),
    @NamedQuery(name = "Tareas.findByComentario", query = "SELECT t FROM Tareas t WHERE t.comentario = :comentario"),
    @NamedQuery(name = "Tareas.findByCreatedAt", query = "SELECT t FROM Tareas t WHERE t.createdAt = :createdAt"),
    @NamedQuery(name = "Tareas.findByUpdatedAt", query = "SELECT t FROM Tareas t WHERE t.updatedAt = :updatedAt")})
public class Tareas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_tarea")
    private Long idTarea;
    @Basic(optional = false)
    @Column(name = "fecha")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Basic(optional = false)
    @Column(name = "prioridad")
    private int prioridad;
    @Basic(optional = false)
    @Column(name = "titulo")
    private String titulo;
    @Basic(optional = false)
    @Column(name = "comentario")
    private String comentario;
    @Basic(optional = false)
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Basic(optional = false)
    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @JoinColumn(name = "categoria_tarea_id_categoria", referencedColumnName = "id_categoria")
    @ManyToOne(optional = false)
    private CategoriaTarea categoriaTareaIdCategoria;
    @JoinColumn(name = "usuarios_idusuarios", referencedColumnName = "idusuarios")
    @ManyToOne(optional = false)
    private Usuarios usuariosIdusuarios;

    public Tareas() {
    }

    public Tareas(Long idTarea) {
        this.idTarea = idTarea;
    }

    public Tareas(Long idTarea, Date fecha, int prioridad, String titulo, String comentario, Date createdAt, Date updatedAt) {
        this.idTarea = idTarea;
        this.fecha = fecha;
        this.prioridad = prioridad;
        this.titulo = titulo;
        this.comentario = comentario;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getIdTarea() {
        return idTarea;
    }

    public void setIdTarea(Long idTarea) {
        this.idTarea = idTarea;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public CategoriaTarea getCategoriaTareaIdCategoria() {
        return categoriaTareaIdCategoria;
    }

    public void setCategoriaTareaIdCategoria(CategoriaTarea categoriaTareaIdCategoria) {
        this.categoriaTareaIdCategoria = categoriaTareaIdCategoria;
    }

    public Usuarios getUsuariosIdusuarios() {
        return usuariosIdusuarios;
    }

    public void setUsuariosIdusuarios(Usuarios usuariosIdusuarios) {
        this.usuariosIdusuarios = usuariosIdusuarios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTarea != null ? idTarea.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tareas)) {
            return false;
        }
        Tareas other = (Tareas) object;
        if ((this.idTarea == null && other.idTarea != null) || (this.idTarea != null && !this.idTarea.equals(other.idTarea))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Tareas[ idTarea=" + idTarea + " ]";
    }
    
}
