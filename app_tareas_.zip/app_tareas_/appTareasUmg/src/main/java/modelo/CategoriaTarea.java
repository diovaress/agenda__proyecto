
package modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author selvi
 */
@Entity
@Table(name = "categoria_tarea")
@NamedQueries({
    @NamedQuery(name = "CategoriaTarea.findAll", query = "SELECT c FROM CategoriaTarea c"),
    @NamedQuery(name = "CategoriaTarea.findByIdCategoria", query = "SELECT c FROM CategoriaTarea c WHERE c.idCategoria = :idCategoria"),
    @NamedQuery(name = "CategoriaTarea.findByDescripcion", query = "SELECT c FROM CategoriaTarea c WHERE c.descripcion = :descripcion"),
    @NamedQuery(name = "CategoriaTarea.findByEstado", query = "SELECT c FROM CategoriaTarea c WHERE c.estado = :estado")})
public class CategoriaTarea implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_categoria")
    private Integer idCategoria;
    @Basic(optional = false)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @Column(name = "estado")
    private int estado;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "categoriaTareaIdCategoria")
    private List<Tareas> tareasList;

    public CategoriaTarea() {
    }

    public CategoriaTarea(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public CategoriaTarea(Integer idCategoria, String descripcion, int estado) {
        this.idCategoria = idCategoria;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public List<Tareas> getTareasList() {
        return tareasList;
    }

    public void setTareasList(List<Tareas> tareasList) {
        this.tareasList = tareasList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCategoria != null ? idCategoria.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CategoriaTarea)) {
            return false;
        }
        CategoriaTarea other = (CategoriaTarea) object;
        if ((this.idCategoria == null && other.idCategoria != null) || (this.idCategoria != null && !this.idCategoria.equals(other.idCategoria))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.CategoriaTarea[ idCategoria=" + idCategoria + " ]";
    }
    
}
